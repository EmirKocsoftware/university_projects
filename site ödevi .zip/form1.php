<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>Kayıt Formu</title>
    <style>
        body { font-family: Arial, sans-serif; background: #eee; padding: 30px; }
        h2 { color: #444; }
        form { background: white; padding: 25px; max-width: 550px; border: 1px solid #ccc; }
        label { display: block; margin-top: 14px; margin-bottom: 4px; font-weight: bold; font-size: 14px; }
        input[type=text], input[type=email], input[type=tel], input[type=url],
        input[type=date], input[type=number], select, textarea {
            width: 100%; padding: 6px 8px; border: 1px solid #aaa; font-size: 14px; box-sizing: border-box;
        }
        textarea { height: 80px; resize: vertical; }
        .radio-grup label, .check-grup label { display: inline; font-weight: normal; margin-left: 5px; }
        .radio-grup div, .check-grup div { margin-top: 4px; }
        input[type=submit] {
            margin-top: 20px; padding: 10px 30px; background: #4a90d9; color: white;
            border: none; font-size: 15px; cursor: pointer;
        }
        input[type=submit]:hover { background: #2c6fad; }
        .basari { background: #d4edda; border: 1px solid #28a745; padding: 12px; margin-bottom: 15px; color: #155724; }
        a { display: inline-block; margin-top: 15px; color: #4a90d9; }
    </style>
</head>
<body>
<h2>📋 Kullanıcı Kayıt Formu (15 Element)</h2>
<a href="index.php">← Ana Sayfa</a>

<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    echo '<div class="basari">✅ Form başarıyla gönderildi! Teşekkürler.</div>';
}
?>

<form method="POST">

    <!-- 1. Text -->
    <label>1. Adınız:</label>
    <input type="text" name="ad" placeholder="Adınızı girin">

    <!-- 2. Text -->
    <label>2. Soyadınız:</label>
    <input type="text" name="soyad" placeholder="Soyadınızı girin">

    <!-- 3. Email -->
    <label>3. E-posta:</label>
    <input type="email" name="email" placeholder="ornek@mail.com">

    <!-- 4. Tel -->
    <label>4. Telefon:</label>
    <input type="tel" name="telefon" placeholder="05xx xxx xx xx">

    <!-- 5. Date -->
    <label>5. Doğum Tarihi:</label>
    <input type="date" name="dogum">

    <!-- 6. Number -->
    <label>6. Yaşınız:</label>
    <input type="number" name="yas" min="1" max="120" placeholder="Yaşınız">

    <!-- 7. URL -->
    <label>7. Web Siteniz:</label>
    <input type="url" name="website" placeholder="https://...">

    <!-- 8. Select -->
    <label>8. Şehir:</label>
    <select name="sehir">
        <option value="">-- Seçiniz --</option>
        <option>İstanbul</option>
        <option>Ankara</option>
        <option>İzmir</option>
        <option>Bursa</option>
        <option>Bilecik</option>
    </select>

    <!-- 9. Select -->
    <label>9. Eğitim Durumu:</label>
    <select name="egitim">
        <option value="">-- Seçiniz --</option>
        <option>İlköğretim</option>
        <option>Lise</option>
        <option>Ön Lisans</option>
        <option>Lisans</option>
        <option>Yüksek Lisans</option>
    </select>

    <!-- 10. Radio -->
    <label>10. Cinsiyet:</label>
    <div class="radio-grup">
        <div><input type="radio" name="cinsiyet" value="erkek"> <label>Erkek</label></div>
        <div><input type="radio" name="cinsiyet" value="kadin"> <label>Kadın</label></div>
        <div><input type="radio" name="cinsiyet" value="diger"> <label>Belirtmek istemiyorum</label></div>
    </div>

    <!-- 11. Radio -->
    <label>11. Üyelik Tipi:</label>
    <div class="radio-grup">
        <div><input type="radio" name="uyelik" value="ucretsiz"> <label>Ücretsiz</label></div>
        <div><input type="radio" name="uyelik" value="premium"> <label>Premium</label></div>
    </div>

    <!-- 12. Checkbox -->
    <label>12. Hobiler:</label>
    <div class="check-grup">
        <div><input type="checkbox" name="hobi[]" value="muzik"> <label>Müzik</label></div>
        <div><input type="checkbox" name="hobi[]" value="spor"> <label>Spor</label></div>
        <div><input type="checkbox" name="hobi[]" value="kitap"> <label>Kitap okuma</label></div>
        <div><input type="checkbox" name="hobi[]" value="oyun"> <label>Oyun</label></div>
    </div>

    <!-- 13. Checkbox -->
    <label>13. Bildirim Tercihi:</label>
    <div class="check-grup">
        <div><input type="checkbox" name="bildirim[]" value="email"> <label>E-posta ile bildir</label></div>
        <div><input type="checkbox" name="bildirim[]" value="sms"> <label>SMS ile bildir</label></div>
    </div>

    <!-- 14. Textarea -->
    <label>14. Hakkınızda kısa bilgi:</label>
    <textarea name="hakkinda" placeholder="Kendinizden bahsedin..."></textarea>

    <!-- 15. Checkbox (sözleşme) -->
    <label>15. Onay:</label>
    <div class="check-grup">
        <div><input type="checkbox" name="sozlesme" value="1"> <label>Kullanım koşullarını okudum ve kabul ediyorum.</label></div>
    </div>

    <input type="submit" value="Gönder">

</form>
</body>
</html>
