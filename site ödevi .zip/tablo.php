<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>Renkli Tablo</title>
    <style>
        body { font-family: Arial, sans-serif; background: #f0f0f0; padding: 30px; }
        h2 { color: #333; }
        form { background: white; padding: 20px; display: inline-block; border: 1px solid #ccc; margin-bottom: 25px; }
        label { font-weight: bold; font-size: 14px; }
        input[type=number] { width: 70px; padding: 5px 8px; margin: 0 10px 0 6px; border: 1px solid #aaa; font-size: 14px; }
        input[type=submit] {
            padding: 7px 22px; background: #27ae60; color: white;
            border: none; font-size: 14px; cursor: pointer;
        }
        input[type=submit]:hover { background: #1e8449; }
        table { border-collapse: collapse; margin-top: 10px; }
        td {
            width: 70px; height: 45px; text-align: center;
            font-size: 13px; font-weight: bold; border: 2px solid white;
            color: white; text-shadow: 1px 1px 2px rgba(0,0,0,0.4);
        }
        .bilgi { font-size: 13px; color: #777; margin-top: 8px; }
        a { display: inline-block; margin-top: 15px; color: #27ae60; }
    </style>
</head>
<body>
<h2>🌈 Rengarenk Tablo</h2>
<a href="index.php">← Ana Sayfa</a>
<br><br>

<form method="GET">
    <label>Satır sayısı:</label>
    <input type="number" name="satir" min="1" max="20" value="<?= isset($_GET['satir']) ? (int)$_GET['satir'] : 5 ?>">
    <label>Sütun sayısı:</label>
    <input type="number" name="sutun" min="1" max="20" value="<?= isset($_GET['sutun']) ? (int)$_GET['sutun'] : 6 ?>">
    <input type="submit" value="Tabloyu Oluştur">
</form>

<?php
$satir = isset($_GET['satir']) ? max(1, min(20, (int)$_GET['satir'])) : 5;
$sutun = isset($_GET['sutun']) ? max(1, min(20, (int)$_GET['sutun'])) : 6;

// Güzel renkler - her yenilemede farklı çünkü rand() kullanıyoruz
$renkler = [
    '#e74c3c','#e67e22','#f1c40f','#2ecc71','#1abc9c',
    '#3498db','#9b59b6','#e91e63','#00bcd4','#ff5722',
    '#8bc34a','#673ab7','#ff9800','#009688','#f44336',
    '#2196f3','#4caf50','#ffeb3b','#795548','#607d8b'
];

echo '<table>';
for ($i = 1; $i <= $satir; $i++) {
    echo '<tr>';
    for ($j = 1; $j <= $sutun; $j++) {
        $renk = $renkler[array_rand($renkler)];
        echo "<td style='background:$renk'>[$i,$j]</td>";
    }
    echo '</tr>';
}
echo '</table>';

echo "<p class='bilgi'>📌 Sayfayı yenileyin → renkler değişir! | $satir satır × $sutun sütun = " . ($satir * $sutun) . " hücre</p>";
?>

</body>
</html>
