<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>Ana Sayfa</title>
    <style>
        body { font-family: Arial, sans-serif; background: #f5f5f5; text-align: center; padding: 60px 20px; }
        h1 { color: #333; margin-bottom: 10px; }
        p { color: #666; margin-bottom: 40px; }
        .links { display: flex; justify-content: center; gap: 20px; flex-wrap: wrap; }
        .links a {
            display: block;
            padding: 20px 30px;
            background: white;
            border: 2px solid #333;
            text-decoration: none;
            color: #333;
            font-size: 16px;
            font-weight: bold;
            width: 200px;
        }
        .links a:hover { background: #333; color: white; }
        .links a span { display: block; font-size: 12px; font-weight: normal; color: #999; margin-top: 6px; }
        .links a:hover span { color: #ccc; }
    </style>
</head>
<body>
    <h1>🎓 PHP Ödev Sitesi</h1>
    <p>Aşağıdaki sayfalardan birine gitmek için tıklayın.</p>
    <div class="links">
        <a href="form1.php">
            1. Site
            <span>15 Elemanlı Form</span>
        </a>
        <a href="form2.php">
            2. Site
            <span>5 Elemanlı Form</span>
        </a>
        <a href="tablo.php">
            3. Site
            <span>Renkli Tablo</span>
        </a>
    </div>
</body>
</html>
