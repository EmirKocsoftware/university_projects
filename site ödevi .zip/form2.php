<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>İletişim Formu</title>
    <style>
        body { font-family: Arial, sans-serif; background: #eee; padding: 30px; }
        h2 { color: #444; }
        form { background: white; padding: 25px; max-width: 450px; border: 1px solid #ccc; }
        label { display: block; margin-top: 14px; margin-bottom: 4px; font-weight: bold; font-size: 14px; }
        input[type=text], input[type=email], select, textarea {
            width: 100%; padding: 6px 8px; border: 1px solid #aaa; font-size: 14px; box-sizing: border-box;
        }
        textarea { height: 100px; resize: vertical; }
        input[type=submit] {
            margin-top: 18px; padding: 9px 28px; background: #e67e22; color: white;
            border: none; font-size: 15px; cursor: pointer;
        }
        input[type=submit]:hover { background: #ca6f1e; }
        .basari { background: #d4edda; border: 1px solid #28a745; padding: 12px; margin-bottom: 15px; color: #155724; }
        .veri { background: #fff3cd; border: 1px solid #ffc107; padding: 12px; margin-top: 15px; font-size: 13px; }
        a { display: inline-block; margin-top: 15px; color: #e67e22; }
    </style>
</head>
<body>
<h2>✉️ İletişim Formu (5 Element)</h2>
<a href="index.php">← Ana Sayfa</a>

<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $ad    = htmlspecialchars($_POST['ad'] ?? '');
    $email = htmlspecialchars($_POST['email'] ?? '');
    $konu  = htmlspecialchars($_POST['konu'] ?? '');
    $mesaj = htmlspecialchars($_POST['mesaj'] ?? '');
    $onay  = isset($_POST['onay']) ? 'Evet' : 'Hayır';

    echo '<div class="basari">✅ Mesajınız alındı! En kısa sürede dönüş yapılacaktır.</div>';
    echo '<div class="veri">';
    echo '<strong>Gönderilen Bilgiler:</strong><br>';
    echo "Ad Soyad: $ad<br>";
    echo "E-posta: $email<br>";
    echo "Konu: $konu<br>";
    echo "Mesaj: $mesaj<br>";
    echo "İnsan mısınız?: $onay";
    echo '</div>';
}
?>

<form method="POST">

    <!-- 1. Text -->
    <label>1. Ad Soyad:</label>
    <input type="text" name="ad" placeholder="Adınız Soyadınız">

    <!-- 2. Email -->
    <label>2. E-posta Adresi:</label>
    <input type="email" name="email" placeholder="mail@adres.com">

    <!-- 3. Select -->
    <label>3. Konu:</label>
    <select name="konu">
        <option value="">-- Konu Seçin --</option>
        <option>Genel Bilgi</option>
        <option>Teknik Destek</option>
        <option>Öneri / Şikayet</option>
        <option>İş Birliği</option>
        <option>Diğer</option>
    </select>

    <!-- 4. Textarea -->
    <label>4. Mesajınız:</label>
    <textarea name="mesaj" placeholder="Mesajınızı buraya yazın..."></textarea>

    <!-- 5. Checkbox -->
    <label>5. Doğrulama:</label>
    <input type="checkbox" name="onay" value="1"> Ben bir robot değilim 🤖

    <br>
    <input type="submit" value="Mesaj Gönder">

</form>
</body>
</html>
